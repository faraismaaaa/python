import math
r=10
r1=30
Sbk=(r**2)*(math.pi)
print(Sbk)
Smk=(r1**2)*(math.pi)
print(Smk)
S=Smk-Sbk
S=math.ceil(S)
print(S)
