import random
a=random.randint(1, 100)
print(a)
b=random.randint(1, 100)
print(b)
print((a+b)**2)# Найти сумму квадратов
print(a**3-b**3)#разность кубов
print(a*b)
print(a/b)
