f=input()
s=['h','e','s','o','y','a','m']
g=0
c=""
if g==0:
    for line in f:
        c+=line
    c.split()
    for i in c:
        if i == s:
            c+=line
            c.remove(i)
print (c)
