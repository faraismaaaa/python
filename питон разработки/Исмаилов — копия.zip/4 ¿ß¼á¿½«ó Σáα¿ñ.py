import random
a=[]
b=[random.randint(1,151) for i in range(40)]
for i in b:
    if i%2==0:
        print(i)
        a.append(i)
print(("Кол-во четных чисел:",len(a)))
