f1=open(r'C:\Users\farid\OneDrive\Рабочий стол\3 задание (1).txt', 'r')
f2=open(r"C:\Users\farid\OneDrive\Рабочий стол\3 задание (2).txt", "w")
#a=f1.read()
c=[]
for line in f1:
    c.append(line)
a=int(c[0])
b=int(c[1])
summa=(a*b)+(b*a)
print(summa)
f2.write(str(summa))
f1.close()
f2.close()
